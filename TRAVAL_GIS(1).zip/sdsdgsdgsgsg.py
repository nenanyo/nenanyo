
from flask import Flask, session, render_template, make_response, jsonify, request, redirect, url_for

import cx_Oracle
import pandas as pd
import numpy as np
import random

import json
import folium
from folium import plugins
import re
import googlemaps
import pprint
import requests
# df = pd.read_csv('./datasets_jeju/data.csv')
# print(df['label'][1])



df11 = pd.DataFrame({"nm":['kim','lee','park'] ,"pw":['111','111','111'] })
# print(df11)

# df11['pww'] = df11['pw']
# df11['pw'] = df11['pww'].apply(lambda x: '222' if x=='112' else cate)
#

AA = "CONT_000000000500811"
print(AA.strip())